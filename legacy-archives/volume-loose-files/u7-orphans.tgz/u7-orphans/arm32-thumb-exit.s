	.syntax unified
	.thumb
	.text
	.globl _start
	.type _start, %function
_start:
	movs	r0, #42
	movs	r7, #1
	svc	#0
	.size	_start, .-_start
