.syntax unified
.arch armv7-a
.text
.arm
.global _start
.type _start,%function
_start:
 mov r8,sp
 mov r4,#0
 mov r0,#0
 bl probe
 mrs r5,apsr
 and r5,r5,#0xf0000000
 mov r6,#0x60000000
 cmp r5,r6
 bne bad
 add r4,r4,r0
 cmp sp,r8
 bne bad
 mov r0,#1
 bl probe
 mrs r5,apsr
 and r5,r5,#0xf0000000
 mov r6,#0x60000000
 cmp r5,r6
 bne bad
 add r4,r4,r0
 cmp sp,r8
 bne bad
 mov r0,#2
 bl probe
 mrs r5,apsr
 and r5,r5,#0xf0000000
 mov r6,#0x20000000
 cmp r5,r6
 bne bad
 add r4,r4,r0
 cmp sp,r8
 bne bad
 cmp r4,#16
 bne bad
 mov r0,#0
 b exit
bad: mov r0,#99
exit: mov r7,#1
 svc #0
 b .
.size _start,.-_start
.balign 4
.global probe
.type probe,%function
.arm
probe:
cmp r0,#0
moveq pc,lr
cmp r0,#1
beq one
mov r0,#7
mov pc,lr
one: mov r0,#9
mov pc,lr
.size probe,.-probe
