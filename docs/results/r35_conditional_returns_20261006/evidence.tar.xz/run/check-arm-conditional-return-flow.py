from pathlib import Path
import json
import shutil
import subprocess
import sys
import tempfile

tc = Path(shutil.which('llvm-bolt')).resolve().parent
runtime = tc.parent / 'bolt-rt-baremetal-arm/libbolt_rt_baremetal.a'
parent = Path(sys.argv[1]); parent.mkdir(parents=True, exist_ok=True)
out = Path(tempfile.mkdtemp(prefix='r35-', dir=parent))
rows = []
qemu = shutil.which('qemu-arm')

def run(label, argv, directory):
    p = subprocess.run([str(x) for x in argv], cwd=directory, capture_output=True, text=True)
    (directory / (label + '.log')).write_text(p.stdout + p.stderr)
    return p

driver = '''.arm
.global _start
.type _start,%function
_start:
 mov r8,sp
 mov r4,#0
 mov r0,#0
 bl probe
 add r4,r4,r0
 cmp sp,r8
 bne bad
 mov r0,#1
 bl probe
 add r4,r4,r0
 cmp sp,r8
 bne bad
 mov r0,#2
 bl probe
 add r4,r4,r0
 cmp sp,r8
 bne bad
 cmp r4,#16
 bne bad
 mov r0,#0
 b exit
bad: mov r0,#99
exit: mov r7,#1
 svc #0
 b .
.size _start,.-_start
'''

cases = []
for kind, push, ret in [('bx', '', 'bx lr'), ('mov', '', 'mov pc,lr'),
                       ('pop', 'push {lr}\n', 'pop {pc}'),
                       ('ldm', 'push {r4,lr}\n', 'pop {r4,pc}')]:
    conditional = ret.replace('bx ', 'bxeq ').replace('mov ', 'moveq ').replace('pop ', 'popeq ')
    body = push + 'cmp r0,#0\n' + conditional + '\ncmp r0,#1\nbeq one\nmov r0,#7\n' + ret + '\none: mov r0,#9\n' + ret
    cases.append(('arm-' + kind, '.arm\n', body, True))
for size in range(1, 5):
    for kind, push, ret in [('bx', '', 'bx lr'), ('pop', 'push {lr}\n', 'pop {pc}'),
                           ('ldm', 'push {r4,lr}\n', 'pop {r4,pc}')]:
        extra = ['moveq r2,r2', 'moveq r3,r3', 'moveq r12,r12'][:size - 1]
        conditional = ret.replace('bx ', 'bxeq ').replace('pop ', 'popeq ')
        body = push + 'cmp r0,#0\ni' + 't' * size + ' eq\n' + '\n'.join(extra + [conditional])
        body += '\ncmp r0,#1\nbeq one\nmov.w r0,#7\n' + ret + '\none: mov.w r0,#9\n' + ret
        cases.append((f'thumb-{kind}-it{size}', '.thumb\n.thumb_func\n', body, True))
cases.append(('thumb-stack-it3', '.thumb\n.thumb_func\n', '''push {r4,lr}
sub sp,#4
cmp r0,#0
ittt eq
moveq r0,r0
addeq sp,#4
popeq {r4,pc}
cmp r0,#1
beq one
mov.w r0,#7
add sp,#4
pop {r4,pc}
one: mov.w r0,#9
add sp,#4
pop {r4,pc}''', True))
cases += [
    ('arm-entry', '.arm\n', 'bxeq lr\nmov r0,#7\nbx lr', False),
    ('arm-targeted-return', '.arm\n', 'cmp r0,#0\nbeq ret\nmov r0,#7\nret: bxeq lr\nbx lr', False),
    ('arm-after-branch', '.arm\n', 'cmp r0,#0\nbne one\nbxeq lr\none: mov r0,#7\nbx lr', False),
    ('thumb-mixed-ite', '.thumb\n.thumb_func\n', 'cmp r0,#0\nite eq\nmoveq r2,#3\nbxne lr\nmov.w r0,#7\nbx lr', False),
]

for name, isa, body, supported in cases:
    directory = out / name; directory.mkdir()
    asm = '.syntax unified\n.arch armv7-a\n.text\n' + driver
    asm += '.balign 4\n.global probe\n.type probe,%function\n' + isa + 'probe:\n' + body + '\n.size probe,.-probe\n'
    (directory / 'in.s').write_text(asm)
    (directory / 'in.ld').write_text('ENTRY(_start)\nSECTIONS { . = 0x10000; .text : { *(.text*) } }\n')
    for label, argv in [('assemble', [tc/'llvm-mc', '-triple=armv7-none-linux-gnueabi', '-arm-add-build-attributes', '-filetype=obj', 'in.s', '-o', 'in.o']),
                        ('link', [tc/'ld.lld', '--emit-relocs', '-T', 'in.ld', 'in.o', '-o', 'in.elf'])]:
        p = run(label, argv, directory)
        assert p.returncode == 0, (name, label, p.stderr)
    if supported and qemu:
        p = run('original-run', [qemu, 'in.elf'], directory)
        assert p.returncode == 0, (name, 'original', p.returncode)
    for mode, options in [('default', []), ('reverse', ['--reorder-blocks=reverse']),
                          ('instrument', ['--instrument']),
                          ('conservative', ['--instrument', '--conservative-instrumentation']),
                          ('instrument-reverse', ['--instrument', '--reorder-blocks=reverse'])]:
        instrument = '--instrument' in options
        candidate = mode + '.elf'
        argv = [tc/'llvm-bolt', 'in.elf', '-o', candidate, '--no-huge-pages', '-lite=0', *options]
        if instrument:
            argv += ['--funcs=probe', '--instrument-calls=false',
                     '--arm-instrumentation-contract=privileged-single-core-no-fiq',
                     '--runtime-instrumentation-lib=' + str(runtime)]
        p = run(mode, argv, directory)
        if instrument and not supported:
            good = p.returncode == 1 and 'does not support conditional returns' in p.stdout+p.stderr and not (directory/candidate).exists()
        else:
            good = p.returncode == 0 and (directory/candidate).exists()
        if good and supported and not instrument and qemu:
            executed = run(mode + '-run', [qemu, candidate], directory)
            good = executed.returncode == 0
        rows.append(dict(case=name, mode=mode, supported=supported, passed=good))
        assert good, (name, mode, p.stdout, p.stderr)
(out/'results.json').write_text(json.dumps(rows, indent=2)+'\n')
print('R35 return/continuation flow:', len(rows), 'PASS; qemu user semantics:', bool(qemu), '; evidence:', out)
