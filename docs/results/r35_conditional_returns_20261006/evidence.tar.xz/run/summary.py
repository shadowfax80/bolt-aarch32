import csv,json,sys,statistics,re
from pathlib import Path
root=Path(__file__).resolve().parents[2]; out=root/'out/r35'
sys.path[:0]=[str(root/'scripts'),str(root/'scripts/pi4')]
from profile_identity import sha256
from stats_util import mean_ci95
performance=[]
for variant,checksum in [(0,'0x2f744325'),(1,'0xce57eab7'),(2,'0x5806b01f')]:
    records=list(csv.DictReader((out/f'counter-performance-v{variant}.csv').open()))
    assert len(records)==12 and all(r['acc']==checksum for r in records)
    means={}; intervals={}
    for name in ['compiler','counter_bolt']:
        rs=[r for r in records if r['variant']==name]
        assert {(int(r['round']),int(r['run'])) for r in rs}=={(i,j) for i in range(1,4) for j in range(1,3)}
        assert all(all(r[field] for field in ['cycles','inst','l1i_refill','l1d_refill','br_mispred','taken','acc']) for r in rs)
        means[name],intervals[name]=mean_ci95([int(r['cycles']) for r in rs])
    performance.append(dict(variant=variant,records=len(records),checksum=checksum,mean_cycles=means,mean_ci95_half_width_cycles=intervals,cycle_change_percent=100*(means['counter_bolt']/means['compiler']-1),csv_sha256=sha256(out/f'counter-performance-v{variant}.csv')))
tests={}
for mode in ['on','off']:
    results=json.loads((out/f'test-{mode}.json').read_text());assert len(results)==115 and all(r['passed'] for r in results)
    tests[mode]=dict(outcomes=len(results),supported_cases=len({r['case'] for r in results if r['supported']}),refusal_cases=len({r['case'] for r in results if not r['supported']}),all_pass=True)
    lit_path=out/('arm-lit-on-final.log' if mode=='on' else 'arm-lit-off-verified.log')
    lit_bytes=lit_path.read_bytes();lit=lit_bytes.decode('utf-16' if lit_bytes.startswith(b'\xff\xfe') else 'utf-8')
    assert 'Passed: 62 (100.00%)' in lit
coverage=json.loads((root/'docs/results/lk_coverage_r35_20261006.json').read_text())
receipt=dict(item='R35',patch='0073-arm-conditional-return-flow.patch',patch_sha256=sha256(root/'overlay/llvm/patches/atfe/0073-arm-conditional-return-flow.patch'),source_identity_sha256=json.loads((out/'replay-final.json').read_text())['source_identity_sha256'],tests=tests,arm_lit_per_mode=62,assertion_mode_output_parity='PASS; identical binaries and ELFs excluding command-line .note.bolt_info only; no new clean-build provenance claim',coverage=dict(functions=coverage['functions'],status_counts=coverage['status_counts'],code_bytes_by_status=coverage['code_bytes_by_status']),counter_flow=json.loads((out/'counter-flow.json').read_text()),rewritten_pc=json.loads((out/'rewritten-pc.json').read_text()),performance=performance,performance_scope='Pi A72 synthetic STAIR_M=8 kernel; stair-0 profile, three interleaved rounds x two runs per image; within-boot runs are not independent population samples. No additive gain or A55 claim.',remaining_guards=['mixed IT predicates','Thumb earlier flag definitions or narrow optional CPSR definitions','A32 entry, targeted or after-control-transfer return'],before='0036 safely refused the exact C1 CS stair kernel; original log remains in C1 receipt',after='Sealed counters admitted, both early-return outcomes measured, original compiler input optimized with bound fdata',certified_gate='18 results and independent reviewed oracle pass; PC evidence for interwork/memcpy, 10 repetitions; other emitted functions are not new execution coverage')
(out/'summary.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(performance,indent=2))
