import hashlib,json,re,tarfile,shutil
from pathlib import Path
root=Path('/mnt/c/Users/User/CURSOR/CodexProjects/BOLT_AARCH32');out=root/'out/r35'; dest=root/'docs/results/r35_conditional_returns_20261006';dest.mkdir(parents=True,exist_ok=True)
def digest(blob):return hashlib.sha256(blob).hexdigest()
entries={}
def include(path,prefix):
    if path.is_file():entries[prefix]=path
    elif path.is_dir():
        for p in sorted(path.rglob('*')):
            if p.is_file():entries[prefix+'/'+str(p.relative_to(path))]=p
# Keep all per-item inputs, receipts and failed attempts. Tool binaries are
# rebuildable from their hashes/pins and would unnecessarily bloat the archive.
for p in sorted(out.iterdir()):
    if p.name!='toolproof':include(p,'run/'+p.name)
for mode,build in [('on','build-atfe'),('off','build-atfe-noassert')]:
    parent=Path('/home/user/bolt-aarch32')/build/'tools/bolt/test/ARM/Output/arm-conditional-return-flow.test.tmp.dir'
    latest=max(parent.glob('r35-*/results.json'),key=lambda p:p.stat().st_mtime).parent
    rows=json.loads((latest/'results.json').read_text());assert len(rows)==115 and all(r['passed'] for r in rows)
    assert len(list(latest.glob('*/original-run.log')))==17
    assert len(list(latest.glob('*/default-run.log')))==len(list(latest.glob('*/reverse-run.log')))==17
    include(latest,'host-fixtures/'+mode)
# Variant-0 measurements predate the dedicated evidence directory.
text=(out/'counter-performance-v0.log').read_text()
for name in re.findall(r'Measurement evidence: .*[/\\](measure-[^\s]+)',text):include(root/'out/pi4'/name,'measurements-v0/'+name)
include(root/'overlay/llvm/patches/atfe/0073-arm-conditional-return-flow.patch','source/0073-arm-conditional-return-flow.patch')
include(root/'docs/results/lk_coverage_r35_20261006.json','coverage/lk_coverage_r35_20261006.json')
archive=dest/'evidence.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as tar:
    for name,p in sorted(entries.items()):tar.add(p,arcname=name,recursive=False)
retained={}
with tarfile.open(archive,'r:xz') as tar:
    for member in tar.getmembers():
        blob=tar.extractfile(member).read();assert blob==entries[member.name].read_bytes(),member.name
        if member.name.endswith('.json'):json.loads(blob)
        retained[member.name]=digest(blob)
summary=json.loads((out/'summary.json').read_text());summary['archive']=dict(file='evidence.tar.xz',sha256=digest(archive.read_bytes()),files=len(retained))
(dest/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(dest/'archive-audit.json').write_text(json.dumps(dict(passed=True,archive_sha256=digest(archive.read_bytes()),files=len(retained),all_files_match_original_bytes=True,members=retained),indent=2)+'\n')
for name in ['counter-flow.json','rewritten-pc.json','replay-final.json','test-on.json','test-off.json','audit-counter.py','watch.py','assertion-parity.sh','build-counter.sh','optimize-counter.sh']:
    shutil.copyfile(out/name,dest/name)
for p in out.glob('counter-performance-v*.csv'):shutil.copyfile(p,dest/p.name)
for name in ['arm-lit-on-final.log','arm-lit-off-verified.log','assertion-parity.log','certified-gate.log','result-parity-verified.log','watch-instrumented.log','watch-optimized.log']:
    raw=(out/name).read_bytes();text=raw.decode('utf-16' if raw.startswith(b'\xff\xfe') else 'utf-8')
    (dest/name).write_text(text)
comparison=next(out.glob('result-consistency-*/comparison.json'));shutil.copyfile(comparison,dest/'result-consistency.json')
gate=next((out/'full-on').glob('pi-verify-*/verification.json'));shutil.copyfile(gate,dest/'certified-gate.json')
print(json.dumps(dict(archive_bytes=archive.stat().st_size,files=len(retained),sha256=digest(archive.read_bytes())),indent=2))
