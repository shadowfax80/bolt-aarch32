import json
import subprocess
from pathlib import Path
root=Path('/mnt/c/Users/User/CURSOR/CodexProjects/BOLT_AARCH32')
skip=json.loads((root/'docs/results/lk_coverage_r35_20261006.json').read_text())['skip_funcs']
for mode,build in [('on','build-atfe'),('off','build-atfe-noassert')]:
    subprocess.run(['python3',str(root/'scripts/pi4/full_image_build.py'),str(root/'out/r35'/('full-'+mode)),
        '--input',str(root/'fixtures/lk-rpi4-bolt-test-424606a8.elf'),
        '--toolchain','/home/user/bolt-aarch32/'+build+'/bin',
        '--redirect-functions','bolt_bench_interwork,bolt_bench_memcpy','--','-skip-funcs='+','.join(skip)],check=True)
print('Candidates built; assertion-parity.sh compares load binaries and ELFs with command-line .note.bolt_info removed.')
