from pathlib import Path
import shutil

src = Path('/home/user/bolt-aarch32/third_party/llvm-project-atfe')
backup = Path('/home/user/bolt-aarch32/out/r35-20261006/before')
files = ['bolt/include/bolt/Core/MCPlusBuilder.h', 'bolt/lib/Target/ARM/ARMMCPlusBuilder.cpp',
         'bolt/lib/Core/BinaryFunction.cpp', 'bolt/lib/Passes/Instrumentation.cpp',
         'bolt/test/ARM/Inputs/check-arm-conditional-instrumentation.py',
         'bolt/test/ARM/arm-conditional-instrumentation.test']
assert not backup.exists(), 'preserve existing backups'
for name in files:
    target = backup / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src / name, target)

def insert(name, before, added):
    path = src / name
    text = path.read_text()
    assert text.count(before) == 1, before
    path.write_text(text.replace(before, added + before))

insert(files[0], '  virtual bool normalizePredicatedBranch(MCInst &Prefix, MCInst &Branch) const {', '''  /// Lower a uniformly predicated sequence ending in a return. Guard skips
  /// the unconditional body when its original condition fails. Return false
  /// without changing anything for unsupported predicates/control transfers.
  virtual bool normalizeConditionalReturnGroup(InstructionListType &Body,
                                               MCInst &Guard,
                                               const MCSymbol *Continuation,
                                               MCContext *Ctx) const {
    return false;
  }

''')
insert(files[1], '  bool normalizePredicatedBranch(MCInst &Prefix,', '''  bool normalizeConditionalReturnGroup(InstructionListType &Body,
                                       MCInst &Guard,
                                       const MCSymbol *Continuation,
                                       MCContext *Ctx) const override {
    if (Body.empty() || !isReturn(Body.back()) || isTerminator(Body.back()))
      return false;
    const int LastPred = Info->get(Body.back().getOpcode()).findFirstPredOperandIdx();
    if (LastPred < 0 || unsigned(LastPred + 1) >= Body.back().getNumOperands() ||
        !Body.back().getOperand(LastPred).isImm())
      return false;
    const int64_t CC = Body.back().getOperand(LastPred).getImm();
    if (CC < 0 || CC >= ARMCC::AL)
      return false;
    // An ITE group may contain work on the opposite path; skipping that work
    // would change the program. Validate the complete group before mutating.
    for (unsigned I = 0; I != Body.size(); ++I) {
      const MCInst &Inst = Body[I];
      const int Pred = Info->get(Inst.getOpcode()).findFirstPredOperandIdx();
      if (Pred < 0 || unsigned(Pred + 1) >= Inst.getNumOperands() ||
          !Inst.getOperand(Pred).isImm() ||
          Inst.getOperand(Pred).getImm() != CC ||
          !Inst.getOperand(Pred + 1).isReg() ||
          Inst.getOperand(Pred + 1).getReg() != ARM::CPSR ||
          (I + 1 != Body.size() &&
           (isBranch(Inst) || isCall(Inst) || isReturn(Inst) || isTerminator(Inst))))
        return false;
    }
    Guard = MCInstBuilder(isThumb() ? ARM::t2Bcc : ARM::Bcc)
                .addExpr(MCSymbolRefExpr::create(Continuation, *Ctx))
                .addImm(ARMCC::getOppositeCondition(static_cast<ARMCC::CondCodes>(CC)))
                .addReg(ARM::CPSR);
    for (MCInst &Inst : Body) {
      const int Pred = Info->get(Inst.getOpcode()).findFirstPredOperandIdx();
      Inst.getOperand(Pred).setImm(ARMCC::AL);
      Inst.getOperand(Pred + 1).setReg(0);
    }
    return true;
  }

''')
insert(files[2], '  // Create basic blocks in the original layout order:', '''  // R35: expose both outcomes of supported conditional returns before CFG
  // construction/profile matching. Thumb uniform IT return groups become a
  // guard at the original IT offset plus an unconditional return path. A32
  // gets a guard after its preceding ordinary instruction; the added guard's
  // profile offset is that instruction's input offset. The return and the
  // continuation keep distinct, original instruction-boundary block offsets.
  // Apply the same lowering for instrumentation and profile consumption.
  DenseMap<uint32_t, MCInst> ARMReturnGuards;
  if (BC.isARM()) {
    for (auto I = Instructions.begin(), E = Instructions.end(); I != E; ++I) {
      auto Last = I;
      InstructionListType Body;
      if (isARMThumb()) {
        const unsigned Size = MIB->getPredicationPrefixSize(I->second);
        if (!Size)
          continue;
        auto B = std::next(I);
        for (unsigned N = 0; N != Size && B != E; ++N, ++B) {
          Body.push_back(B->second);
          Last = B;
        }
        if (Body.size() != Size)
          continue;
      } else {
        if (!MIB->isReturn(I->second) || MIB->isTerminator(I->second) ||
            I == Instructions.begin() || Labels.count(I->first))
          continue;
        const MCInst &Prev = std::prev(I)->second;
        // A second control transfer cannot share the predecessor's profile
        // site. Leave these shapes intact for the instrumentation guard.
        if (MIB->isBranch(Prev) || MIB->isCall(Prev) || MIB->isReturn(Prev) ||
            MIB->isTerminator(Prev))
          continue;
        Body.push_back(I->second);
      }
      const auto Next = std::next(Last);
      if (Next == E)
        continue; // A failed condition may not run off the function end.
      MCInst Guard;
      MCSymbol *Continuation = getOrCreateLocalLabel(getAddress() + Next->first);
      if (!MIB->normalizeConditionalReturnGroup(Body, Guard, Continuation,
                                               BC.Ctx.get()))
        continue;
      if (isARMThumb()) {
        MIB->setOffset(Guard, I->first);
        I->second = std::move(Guard);
        auto B = std::next(I);
        getOrCreateLocalLabel(getAddress() + B->first);
        for (MCInst &Inst : Body) {
          B->second = std::move(Inst);
          ++B;
        }
        TakenBranches.emplace_back(I->first, Next->first);
        I = Last;
      } else {
        const auto Prev = std::prev(I);
        MIB->setOffset(Guard, Prev->first);
        ARMReturnGuards[Prev->first] = std::move(Guard);
        I->second = std::move(Body.front());
        getOrCreateLocalLabel(getAddress() + I->first);
        TakenBranches.emplace_back(Prev->first, Next->first);
      }
    }
  }

''')
p = src / files[2]
text = p.read_text()
needle = '    const bool IsBlockEnd = MIB->isTerminator(Instr);'
assert text.count(needle) == 1
text = text.replace(needle, '    bool IsBlockEnd = MIB->isTerminator(Instr);')
needle = '    addCFIPlaceholders(CFIOffset, InsertBB);\n\n    if (IsBlockEnd) {'
assert text.count(needle) == 1
text = text.replace(needle, '''    addCFIPlaceholders(CFIOffset, InsertBB);

    if (auto Guard = ARMReturnGuards.find(Offset);
        Guard != ARMReturnGuards.end()) {
      InsertBB->addInstruction(std::move(Guard->second));
      IsBlockEnd = true;
    }

    if (IsBlockEnd) {''')
p.write_text(text)
p = src / files[3]
text = p.read_text().replace('  // A conditional return is kept inside an ARM block to preserve its\n  // fallthrough, but its taken exit has no CFG edge. Spanning-tree profiling\n  // would miss paths that return before the leaf counters. Refuse to publish\n  // such a profile until both exit and fallthrough are modeled.', '''  // Supported conditional returns were lowered to explicit return and
  // continuation blocks during CFG construction (R35). A remaining return
  // with fallthrough has an unsupported shape (e.g. a mixed-predicate IT
  // group or an A32 return without a safe predecessor profile site). Refuse
  // it: spanning-tree profiling would otherwise miss its early exit.''')
p.write_text(text)
print('R35 initial lowering installed; backups:', backup)
