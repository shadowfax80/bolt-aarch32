from pathlib import Path
src = Path('/home/user/bolt-aarch32/third_party/llvm-project-atfe')
p = src / 'bolt/lib/Target/ARM/ARMMCPlusBuilder.cpp'
t = p.read_text()
needle = '''        return false;
    }
    Guard = MCInstBuilder(InThumbMode() ? ARM::t2Bcc : ARM::Bcc)'''
assert t.count(needle) == 1
p.write_text(t.replace(needle, '''        return false;
      if (InThumbMode() && I + 1 != Body.size()) {
        const MCInstrDesc &Desc = Info->get(Inst.getOpcode());
        // A single guard cannot replace predicates that depend on flags
        // changed by an earlier body instruction. Also, narrow Thumb data
        // instructions with an optional CPSR def suppress their flag update
        // inside IT, but set flags outside IT even when MC carries NoRegister.
        // Keep both shapes under the refusal guard until safely widened.
        if (hasDefOfPhysReg(Inst, ARM::CPSR) ||
            llvm::is_contained(Desc.implicit_defs(), ARM::CPSR) ||
            (Desc.getSize() == 2 && Desc.hasOptionalDef()))
          return false;
      }
    }
    Guard = MCInstBuilder(InThumbMode() ? ARM::t2Bcc : ARM::Bcc)'''))
p = src / 'bolt/test/ARM/Inputs/check-arm-conditional-return-flow.py'
t = p.read_text().replace("'--funcs=probe', '--instrument-calls=false',", "'--funcs=probe', '--instrument-calls=false', '--instrumentation-sleep-time=1',")
needle = "    ('thumb-mixed-ite', '.thumb\\n.thumb_func\\n', 'cmp r0,#0\\nite eq\\nmoveq r2,#3\\nbxne lr\\nmov.w r0,#7\\nbx lr', False),"
assert t.count(needle) == 1
t = t.replace(needle, needle + "\n    ('thumb-narrow-flags', '.thumb\\n.thumb_func\\n', 'cmp r0,#0\\nitt eq\\naddeq r2,r2,#1\\nbxeq lr\\nmov.w r0,#7\\nbx lr', False),\n    ('thumb-changing-flags', '.thumb\\n.thumb_func\\n', 'cmp r0,#0\\nitt eq\\ncmpeq r2,#3\\nbxeq lr\\nmov.w r0,#7\\nbx lr', False),")
p.write_text(t)
