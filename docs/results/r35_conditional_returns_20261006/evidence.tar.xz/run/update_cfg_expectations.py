from pathlib import Path
import shutil
src = Path('/home/user/bolt-aarch32/third_party/llvm-project-atfe')
backup = Path('/home/user/bolt-aarch32/out/r35-20261006/before')
names = ['bolt/test/ARM/arm-pop-cfg.test', 'bolt/test/ARM/arm-predicated-returns-calls.test',
         'bolt/test/ARM/Inputs/check-arm-predicated-returns-calls.py']
for name in names:
    target = backup/name
    assert not target.exists()
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src/name, target)
p = src/names[0]
t = p.read_text().replace('## retain their live fallthrough instructions.', '## retain live fallthrough; supported predicated returns get explicit CFG exits.')
t = t.replace('CHECK: popeq\nCHECK: mov{{.*}}#42', 'CHECK: bne\nCHECK: pop\nCHECK: mov{{.*}}#42')
p.write_text(t)
(src/names[1]).write_text('''## Predicated calls and unsupported return groups retain IT state/conditions.
## R35 lowers a flag-invariant uniform return group to an explicit CFG exit;
## call targets still reach moved callees, including through LongJmp stubs.
RUN: rm -rf %t.dir
RUN: %python %p/Inputs/check-arm-predicated-returns-calls.py %t.dir
''')
p = src/names[2]
t = p.read_text()
old = "        ok = moved and same\n        detail = ''"
assert t.count(old) == 1
p.write_text(t.replace(old, '''        ok = moved and same
        detail = ''
        if name == 't_ret':
            # R35: single-IT return is now a guard and an unconditional BX.
            seq = [insts[a][1:] for a in order if insts[a][0] == name]
            normalized = (not it_groups(name, insts, order) and
                          any(re.fullmatch(r'b(?:eq|ne)(?:\\.w)?', m) for m, _ in seq) and
                          any(m == 'bx' and o == 'lr' for m, o in seq) and
                          not any(m == 'bxeq' for m, _ in seq))
            ok = moved and normalized
            detail = f'; return CFG normalized={normalized}' '''))
