from pathlib import Path
p = Path('/home/user/bolt-aarch32/third_party/llvm-project-atfe/bolt/test/ARM/Inputs/check-arm-conditional-return-flow.py')
t = p.read_text()
old = ' bl probe\n add r4,r4,r0\n cmp sp,r8'
assert t.count(old) == 3
checks = ['0x60000000', '0x60000000', '0x20000000']
for expected in checks:
    t = t.replace(old, ''' bl probe
 mrs r5,apsr
 and r5,r5,#0xf0000000
 mov r6,#''' + expected + '''
 cmp r5,r6
 bne bad
 add r4,r4,r0
 cmp sp,r8''', 1)
p.write_text(t)
