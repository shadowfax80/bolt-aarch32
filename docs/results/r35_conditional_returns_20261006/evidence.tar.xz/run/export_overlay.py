import difflib
from pathlib import Path

src = Path('/home/user/bolt-aarch32/third_party/llvm-project-atfe')
backup = Path('/home/user/bolt-aarch32/out/r35-20261006/before')
dst = Path('/mnt/c/Users/User/CURSOR/CodexProjects/BOLT_AARCH32/overlay/llvm/patches/atfe/0073-arm-conditional-return-flow.patch')
names = sorted(str(p.relative_to(backup)) for p in backup.rglob('*') if p.is_file())
names += ['bolt/test/ARM/Inputs/check-arm-conditional-return-flow.py', 'bolt/test/ARM/arm-conditional-return-flow.test']
parts = []
for name in names:
    before = (backup/name).read_text().splitlines(True) if (backup/name).exists() else []
    after = (src/name).read_text().splitlines(True)
    if before != after:
        parts.append(''.join(difflib.unified_diff(before, after, fromfile='a/'+name if before else '/dev/null', tofile='b/'+name)))
dst.write_text(''.join(parts))
print('Exported', dst, 'files:', len(parts))
