from pathlib import Path
p = Path('/home/user/bolt-aarch32/third_party/llvm-project-atfe/bolt/lib/Core/BinaryFunction.cpp')
t = p.read_text()
needle = '      MCInst Guard;\n      MCSymbol *Continuation = getOrCreateLocalLabel'
assert t.count(needle) == 1
p.write_text(t.replace(needle, '''      MCInst Guard;
      // buildCFG runs concurrently across functions. Label creation and
      // expression allocation share MCContext, unlike the per-function maps.
      auto ContextLock = BC.scopeLock();
      MCSymbol *Continuation = getOrCreateLocalLabel'''))
