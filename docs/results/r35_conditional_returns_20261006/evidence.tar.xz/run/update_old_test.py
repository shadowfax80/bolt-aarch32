from pathlib import Path
src = Path('/home/user/bolt-aarch32/third_party/llvm-project-atfe')
p = src / 'bolt/test/ARM/Inputs/check-arm-conditional-instrumentation.py'
t = p.read_text()
needle = "good=p.returncode==1 and 'AArch32 instrumentation does not support conditional returns' in p.stdout+p.stderr and not candidate.exists() if instrument else p.returncode==0 and candidate.exists()"
assert t.count(needle) == 1
p.write_text(t.replace(needle, 'good=p.returncode==0 and candidate.exists()'))
p = src / 'bolt/test/ARM/arm-conditional-instrumentation.test'
p.write_text('''## R35: preceding A32 comparison sites permit explicit return/continuation
## blocks. Relocation and every tested instrumentation mode must succeed.
RUN: %python %p/Inputs/check-arm-conditional-instrumentation.py %t.dir
''')
