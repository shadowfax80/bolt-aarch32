from pathlib import Path
src = Path('/home/user/bolt-aarch32/third_party/llvm-project-atfe')
p = src / 'bolt/lib/Target/ARM/ARMMCPlusBuilder.cpp'
t = p.read_text()
assert t.count('MCInstBuilder(isThumb() ? ARM::t2Bcc : ARM::Bcc)') == 1
p.write_text(t.replace('MCInstBuilder(isThumb() ? ARM::t2Bcc : ARM::Bcc)', 'MCInstBuilder(InThumbMode() ? ARM::t2Bcc : ARM::Bcc)'))
p = src / 'bolt/lib/Core/BinaryFunction.cpp'
t = p.read_text()
needle = '      const auto Next = std::next(Last);\n      if (Next == E)'
assert t.count(needle) == 1
p.write_text(t.replace(needle, '''      if (Body.empty() || !MIB->isReturn(Body.back()) ||
          MIB->isTerminator(Body.back()))
        continue;
      const auto Next = std::next(Last);
      if (Next == E)'''))
