#!/usr/bin/env bash
set -euo pipefail
ROOT=/home/user/bolt-fe-20261006
WIN=/mnt/c/Users/User/CURSOR/CodexProjects/BOLT_AARCH32
export BASE=atfe TOOLCHAIN=/home/user/bolt-aarch32/build-atfe/bin
export BOLT_RT_LIB=/home/user/bolt-aarch32/build-atfe/bolt-rt-baremetal-arm/libbolt_rt_baremetal.a
export ARM_INSTRUMENTATION_CONTRACT=privileged-single-core-no-fiq BOLT_FUNC=bolt_bench_stair_kernel BOLT_PROFILE_MODE=edges
export SOURCE_REPLAY="$ROOT/out/c3-replay/replay.json"
V="$ROOT/build-atfe/c3-fe-thumb"
cd "$ROOT"
for flavor in sample counter; do
  mkdir "$ROOT/build-atfe/c3-$flavor"
  cp "$V/pgo_thinlto."{elf,bin} "$ROOT/build-atfe/c3-$flavor/"
done
export VARIANTS_DIR="$ROOT/build-atfe/c3-counter"
bash scripts/bolt-variant.sh instrument pgo_thinlto
python3 scripts/profile_identity.py seal-counters --original "$VARIANTS_DIR/pgo_thinlto.elf" --elf "$VARIANTS_DIR/pgo_thinlto.instr.elf" --map "$VARIANTS_DIR/pgo_thinlto.instr.funcmap" --image "$VARIANTS_DIR/pgo_thinlto.instr.bin" --toolchain "$TOOLCHAIN" --patch-dir overlay/llvm/patches/atfe --source-replay "$SOURCE_REPLAY"
bash scripts/check-no-fpu.sh "$VARIANTS_DIR/pgo_thinlto.instr.elf" > "$VARIANTS_DIR/instr.nofpu.log"
export VARIANTS_DIR="$ROOT/build-atfe/c3-sample"
python3 scripts/profile_identity.py seal-samples --elf "$VARIANTS_DIR/pgo_thinlto.elf" --image "$VARIANTS_DIR/pgo_thinlto.bin" --toolchain "$TOOLCHAIN" --patch-dir overlay/llvm/patches/atfe
mkdir -p "$WIN/out/c3-fe/counter" "$WIN/out/c3-fe/sample"
cp "$ROOT/build-atfe/c3-counter"/* "$WIN/out/c3-fe/counter/"
cp "$ROOT/build-atfe/c3-sample"/* "$WIN/out/c3-fe/sample/"
