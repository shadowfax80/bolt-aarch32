#pragma once
#define STAIR_M 8
#define STAIR_X 0
#define MODULE_NAME "app/bolt_bench"
#define MODULE_OPTIONS ""
#define MODULE_COMPILEFLAGS "-fprofile-instr-use=/home/user/bolt-fe-20261006/build-atfe/c3-fe-thumb/frontend.profdata_-Wno-profile-instr-unprofiled"
#define MODULE_CFLAGS ""
#define MODULE_CPPFLAGS ""
#define MODULE_ASMFLAGS ""
#define MODULE_OPTFLAGS ""
#define MODULE_INCLUDES ""
#define MODULE_SRCDEPS ""
#define MODULE_DEPS "lib/console_"
#define MODULE_WEAK_DEPS ""
#define MODULE_SRCS "app/bolt_bench/bolt_bench.c_app/bolt_bench/composite.c_"
#define MODULE_FLOAT_SRCS ""
#define MODULE_ARM_OVERRIDE_SRCS ""

