import json,struct,sys,collections
from pathlib import Path
root=Path(__file__).resolve().parents[2];out=root/'out/c3-fe';d=out/'counter'
sys.path[:0]=[str(root/'scripts'),str(root/'scripts/pi4')]
from counter_identity import check_capture,converter
from profile_identity import sha256
from measurement_records import parse_measurements
capture,ctx,funcs=check_capture(str(d/'stair0.counters.bin')+'.manifest.json',d/'stair0.counters.bin',d/'pgo_thinlto.elf',d/'pgo_thinlto.instr.elf',d/'pgo_thinlto.instr.funcmap',root/'out/r35/toolproof',root/'overlay/llvm/patches/atfe',out/'replay.json')
log=Path(capture['evidence'])/'capture.log';assert sha256(log)==capture['log_sha256']
rows=parse_measurements(log.read_text(),'bolt_bench stair 0 0',['stair'],1);assert rows[0]['acc']=='0x2f744325'
layout=capture['build']['metadata']['counter_layout'];raw=(d/'stair0.counters.bin').read_bytes()
counts=list(struct.unpack_from('<'+str(layout['count'])+'Q',raw,layout['locations']-layout['address']))
assert len(funcs)==1
f=funcs[0];graph=converter().Graph(f,counts,{});incoming=collections.defaultdict(int);outgoing=collections.defaultdict(int)
for e,n in zip(f.edges,graph.edge_freqs):incoming[e.to_node]+=n;outgoing[e.from_node]+=n
nodes=set(incoming)|set(outgoing);entries=nodes-{e.to_node for e in f.edges};exits=nodes-{e.from_node for e in f.edges}
assert len(entries)==1
for n in nodes-entries-exits:assert incoming[n]==outgoing[n],(n,incoming[n],outgoing[n])
entry_count=sum(outgoing[n] for n in entries);exit_count=sum(incoming[n] for n in exits)
assert entry_count==exit_count==1600
(out/'counter-flow.json').write_text(json.dumps(dict(passed=True,counters=len(counts),entries=entry_count,exits=exit_count,all_internal_flow_conserved=True,checksum=rows[0]['acc'],capture_manifest_sha256=sha256(str(d/'stair0.counters.bin')+'.manifest.json'),scope='Exact bound frontend ThinLTO kernel counters; source specifies 100 warmups +1500 calls. Output association is not a new algorithmic oracle.'),indent=2)+'\n')
print('PASS:',len(counts),'counters; 1600 entries/exits; all internal flow balances')
