#!/usr/bin/env bash
set -euo pipefail
ROOT=/home/user/bolt-fe-20261006
WIN=/mnt/c/Users/User/CURSOR/CodexProjects/BOLT_AARCH32
export BASE=atfe TOOLCHAIN=/home/user/bolt-aarch32/build-atfe/bin
export VARIANTS_DIR="$ROOT/build-atfe/c3-sample" BOLT_FUNC=bolt_bench_stair_kernel
cd "$ROOT"
cp "$WIN/out/c3-fe/sample/stair0.samples"* "$VARIANTS_DIR/"
SKIP=$(python3 -c "import json; print(','.join(json.load(open('build-atfe/c3-fe-thumb/pgo_thinlto.coverage.json'))['skip_funcs']))")
python3 scripts/samples_to_fdata.py "$VARIANTS_DIR/pgo_thinlto.elf" "$VARIANTS_DIR/stair0.samples" -o "$VARIANTS_DIR/pgo_thinlto.samples.fdata" --toolchain "$TOOLCHAIN" --functions bolt_bench_stair_kernel --skip-funcs "$SKIP"
export BOLT_FDATA="$VARIANTS_DIR/pgo_thinlto.samples.fdata"
bash scripts/bolt-variant.sh optimize pgo_thinlto
bash scripts/check-no-fpu.sh "$VARIANTS_DIR/pgo_thinlto_bolt.elf" > "$VARIANTS_DIR/bolt.nofpu.log"
cp "$VARIANTS_DIR"/* "$WIN/out/c3-fe/sample/"
