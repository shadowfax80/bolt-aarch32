import collections,csv,hashlib,json,re,shutil,sys,tarfile
from pathlib import Path
root=Path(__file__).resolve().parents[2]; out=root/'out/c3-fe'
dest=root/'docs/results/c3_frontend_pgo_20261006';dest.mkdir(parents=True,exist_ok=True)
sys.path[:0]=[str(root/'scripts/pi4'),str(root/'scripts')]
from measurement_records import parse_measurements
from profile_identity import sha256
identity=json.loads((out/'identity.json').read_text())
final=json.loads((out/'identity-final.json').read_text());assert final==identity
assert sha256(out/'compiler/pgo_thinlto-module-config.h')==identity['module_config_sha256']
assert sha256(out/'compiler/pgo_thinlto-bolt_bench.c.o')==identity['thinlto_object_sha256']
images={'baseline':out/'compiler/baseline.bin','fe_pgo':out/'compiler/pgo.bin','fe_thinlto':out/'compiler/pgo_thinlto.bin','counter_bolt':out/'counter/pgo_thinlto_bolt.bin','sampled_bolt':out/'sample/pgo_thinlto_bolt.bin'}
boots=[]
for name in ['bolt-performance-v0','bolt-performance-v1','bolt-performance-v2','compiler-performance']:
    rows=list(csv.DictReader((out/(name+'.csv')).open()))
    directories=re.findall(r'Measurement evidence: .*?(measure-[^\s]+)',(out/(name+'.log')).read_text())
    assert len(directories)==6 and len(rows)==12
    for i,dirname in enumerate(directories):
        d=out/dirname;receipt=json.loads((d/'measurement.json').read_text())
        assert sha256(d/'image.bin')==receipt['image_sha256']==sha256(images[rows[2*i]['variant']])
        assert sha256(d/'serial.log')==receipt['serial_sha256']
        assert sha256(d/'loader.img')==sha256(root/'tools/pi4-serialboot-fast/kernel7l_fast.img')
        parsed=parse_measurements((d/'serial.log').read_text(),receipt['command'],['stair'],2)
        assert parsed==receipt['rows'] and '$ wdog 180' in (d/'serial.log').read_text() and '$ wdog 0' in (d/'serial.log').read_text()
        for a,b in zip(parsed,rows[2*i:2*i+2]):
            assert a['acc']==b['acc'] and a['run']==int(b['run'])
            for field in ['cycles','inst','l1i_refill','l1d_refill','br_mispred','taken']:assert a[field]==int(b[field])
        boots.append(dict(set=name,evidence=dirname,receipt_sha256=sha256(d/'measurement.json')))
assert len({b['evidence'] for b in boots})==24
pc=json.loads((out/'rewritten-pc.json').read_text())
for row in pc['rows']:
    label=row['label'];folder,stem=('counter','pgo_thinlto.instr') if label=='instrumented' else ('counter' if label=='counter-bolt' else 'sample','pgo_thinlto_bolt')
    assert sha256(out/folder/(stem+'.bin'))==row['image_sha256'] and sha256(out/folder/(stem+'.elf'))==row['elf_sha256']
    log=out/('watch-'+label+'.log');assert sha256(log)==row['log_sha256']
    assert len(parse_measurements(log.read_text(),'bolt_bench stair 0 0',['stair'],2))==2
    assert sum(row['hits_per_core'])>0
shutil.copyfile(root/'docs/results/lk_coverage_c3_20261006.json',out/'certified-coverage.json')
audit=dict(passed=True,accepted_boots=24,complete_csv_records=48,raw_frames_reparsed=True,exact_uploaded_images=True,loader_bound=True,watch_logs_bound=True,source_tools_unchanged=True,failed_measurements_excluded=['failed-performance-v0.csv','measure-rkswmrja'],boots=boots)
(out/'evidence-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
names=['identity.json','identity-final.json','replay.json','counter-flow.json','rewritten-pc.json','evidence-audit.json','assertion-parity.log','counter-flow.log','rewritten-pc.log','summary-output.log','result-parity.log','certified-coverage.log']
names += [n+suffix for n in ['bolt-performance-v0','bolt-performance-v1','bolt-performance-v2','compiler-performance'] for suffix in ['.csv','.log']]
names += ['watch-'+label+'.log' for label in ['instrumented','counter-bolt','sampled-bolt']]
for n in names:shutil.copyfile(out/n,dest/n)
shutil.copyfile(out/'compiler/frontend-profile.json',dest/'frontend-profile.json')
shutil.copyfile(out/'frontend-training/collection.json',dest/'frontend-collection.json')
shutil.copyfile(next(out.glob('result-consistency-*/comparison.json')),dest/'result-consistency.json')
summary=json.loads((out/'summary.json').read_text());summary.pop('compiler_identity')
summary['compiler_identity_file']='identity.json';summary['compiler_identity_sha256']=sha256(dest/'identity.json')
summary['evidence_audit']=audit
(dest/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files={str(p.relative_to(out)).replace('\\','/'):sha256(p) for p in sorted(out.rglob('*')) if p.is_file()}
archive=dest/'evidence.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as tar:
    for name in files:tar.add(out/name,arcname='c3-fe/'+name,recursive=False)
seen={}
with tarfile.open(archive,'r:xz') as tar:
    for member in tar:
        assert member.isfile() and member.name.startswith('c3-fe/') and '..' not in Path(member.name).parts
        name=member.name[len('c3-fe/'):];payload=tar.extractfile(member).read();seen[name]=hashlib.sha256(payload).hexdigest()
        assert seen[name]==files[name]
        if name.endswith('.json'):json.loads(payload)
assert seen==files
published={p.name:sha256(p) for p in dest.iterdir() if p.is_file() and p.name not in ['README.md','integrity.json','repo-health.log','staged-byte-audit.log']}
(dest/'integrity.json').write_text(json.dumps(dict(archive='evidence.tar.xz',archive_sha256=sha256(archive),archive_bytes=archive.stat().st_size,files=files,published_sha256=published,archive_members_verified=len(files),scope='Exact file bytes and JSON readability; original absolute receipt paths are historical, archive paths are relative to c3-fe/'),indent=2)+'\n')
print('PASS: 24 bound boots / 48 raw-framed records; 3 PC logs; unchanged source/tools; archive verified:',len(files),'files,',archive.stat().st_size,'bytes')
