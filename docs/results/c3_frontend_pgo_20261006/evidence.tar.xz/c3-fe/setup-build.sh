#!/usr/bin/env bash
set -euo pipefail
WIN=/mnt/c/Users/User/CURSOR/CodexProjects/BOLT_AARCH32
ROOT=/home/user/bolt-fe-20261006
test ! -e "$ROOT"
git clone --no-hardlinks "$WIN" "$ROOT"
mkdir -p "$ROOT/third_party"
git clone --no-hardlinks /home/user/bolt-cspgo/third_party/lk "$ROOT/third_party/lk"
git -C "$ROOT/third_party/lk" checkout --detach 79d2f56096fa32365846ceaba8b4a9d1c6b75cf0
export BASE=atfe CLANG_BINDIR=/home/user/bolt-aarch32/build-atfe/bin TOOLCHAIN=/home/user/bolt-aarch32/build-atfe/bin
export VARIANTS_DIR="$ROOT/build-atfe/c3-fe" LK_PROJECT=rpi4-bolt-test LK_MAKE_ARGS=STAIR_M=8 JOBS=8
cd "$ROOT"
bash scripts/build-variants.sh baseline pgo-collect
mkdir -p "$WIN/out/c3-fe/compiler"
cp "$VARIANTS_DIR"/* "$WIN/out/c3-fe/compiler/"
python3 "$WIN/scripts/verify-atfe-overlays.py" --source /home/user/bolt-aarch32/third_party/llvm-project-atfe --patch-dir "$ROOT/overlay/llvm/patches/atfe" --out "$ROOT/out/c3-replay"
cp "$ROOT/out/c3-replay/replay.json" "$WIN/out/c3-fe/replay.json"
