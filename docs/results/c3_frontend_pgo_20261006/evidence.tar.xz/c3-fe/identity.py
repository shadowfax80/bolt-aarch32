import hashlib,json,subprocess
from pathlib import Path
root=Path('/home/user/bolt-fe-20261006');out=Path('/mnt/c/Users/User/CURSOR/CodexProjects/BOLT_AARCH32/out/c3-fe')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
lk=root/'third_party/lk'
source={}
for p in sorted(lk.rglob('*')):
    rel=p.relative_to(lk)
    if p.is_file() and not any(x=='.git' or x.startswith('build-') or x in ('.overlay-source-ok','.applied-overlay-patches') for x in rel.parts):source[str(rel)]=sha(p)
tc=Path('/home/user/bolt-aarch32/build-atfe/bin')
tools={n:sha(tc/n) for n in ['clang','ld.lld','llvm-profdata','llvm-bolt','perf2bolt','llvm-objcopy','llvm-readelf','llvm-nm','llvm-objdump']}
compiler=root/'build-atfe/c3-fe-thumb';artifacts={str(p.relative_to(compiler)):sha(p) for p in sorted(compiler.rglob('*')) if p.is_file()}
config=lk/'build-rpi4-bolt-test/app/bolt_bench/module_config.h'
flags=config.read_text();assert '-fprofile-instr-use=' in flags and '#define STAIR_M 8' in flags
obj=lk/'build-rpi4-bolt-test/app/bolt_bench/bolt_bench.c.o';kind=subprocess.check_output(['file',str(obj)],text=True);assert 'LLVM IR bitcode' in kind
receipt=dict(repo_revision=subprocess.check_output(['git','-C',root,'rev-parse','HEAD'],text=True).strip(),lk_pin=subprocess.check_output(['git','-C',lk,'rev-parse','HEAD'],text=True).strip(),source_tree_sha256=hashlib.sha256(json.dumps(source,sort_keys=True).encode()).hexdigest(),lk_source_files=source,tool_sha256=tools,pgo_runtime_sha256=sha(Path('/home/user/bolt-aarch32/build-atfe/pgo-rt-baremetal-arm/libpgo_rt_baremetal.a')),bolt_runtime_sha256=sha(Path('/home/user/bolt-aarch32/build-atfe/bolt-rt-baremetal-arm/libbolt_rt_baremetal.a')),compiler_artifact_sha256=artifacts,module_config_sha256=sha(config),thinlto_object_sha256=sha(obj),thinlto_object_format=kind.strip(),compile_options=['STAIR_M=8','BOLT_BENCH_ISA=thumb','-mfpu=none','frontend profile use','module ThinLTO'],source_replay_sha256=sha(out/'replay.json'),scope='Fresh source at LK pin plus current repository overlays; compiler tools/runtimes and generated artifacts bound by hashes. Compiler frontend collection/use and actual module bitcode verified; not a clean LLVM build certificate.')
(out/'identity.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Bound',len(source),'LK source files,',len(artifacts),'compiler artifacts; ThinLTO bitcode and frontend-use flags verified')
