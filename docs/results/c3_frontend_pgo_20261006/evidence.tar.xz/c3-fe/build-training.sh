#!/usr/bin/env bash
set -euo pipefail
ROOT=/home/user/bolt-fe-20261006
WIN=/mnt/c/Users/User/CURSOR/CodexProjects/BOLT_AARCH32
export BASE=atfe CLANG_BINDIR=/home/user/bolt-aarch32/build-atfe/bin TOOLCHAIN=/home/user/bolt-aarch32/build-atfe/bin
export VARIANTS_DIR="$ROOT/build-atfe/c3-fe-thumb" LK_PROJECT=rpi4-bolt-test LK_MAKE_ARGS=STAIR_M=8 BOLT_BENCH_ISA=thumb JOBS=8
export PGO_RT_LIB=/home/user/bolt-aarch32/build-atfe/pgo-rt-baremetal-arm/libpgo_rt_baremetal.a
cd "$ROOT"
bash scripts/build-variants.sh baseline pgo-collect
mkdir -p "$WIN/out/c3-fe/compiler"
cp "$VARIANTS_DIR"/* "$WIN/out/c3-fe/compiler/"
python3 scripts/verify-atfe-overlays.py --source /home/user/bolt-aarch32/third_party/llvm-project-atfe --patch-dir "$ROOT/overlay/llvm/patches/atfe" --out "$ROOT/out/c3-replay"
cp "$ROOT/out/c3-replay/replay.json" "$WIN/out/c3-fe/replay.json"
