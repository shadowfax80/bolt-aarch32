#!/usr/bin/env bash
set -euo pipefail
ROOT=/home/user/bolt-fe-20261006
WIN=/mnt/c/Users/User/CURSOR/CodexProjects/BOLT_AARCH32
export BASE=atfe TOOLCHAIN=/home/user/bolt-aarch32/build-atfe/bin
export VARIANTS_DIR="$ROOT/build-atfe/c3-counter" BOLT_FUNC=bolt_bench_stair_kernel
export SOURCE_REPLAY="$ROOT/out/c3-replay/replay.json"
cd "$ROOT"
cp "$WIN/out/c3-fe/counter/stair0.counters.bin"* "$VARIANTS_DIR/"
bash scripts/bolt-variant.sh optimize pgo_thinlto "$VARIANTS_DIR/stair0.counters.bin"
bash scripts/check-no-fpu.sh "$VARIANTS_DIR/pgo_thinlto_bolt.elf" > "$VARIANTS_DIR/bolt.nofpu.log"
cp "$VARIANTS_DIR"/* "$WIN/out/c3-fe/counter/"
