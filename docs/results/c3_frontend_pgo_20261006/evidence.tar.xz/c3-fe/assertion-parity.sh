#!/usr/bin/env bash
set -euo pipefail
ROOT=/home/user/bolt-fe-20261006
WIN=/mnt/c/Users/User/CURSOR/CodexProjects/BOLT_AARCH32
export BASE=atfe TOOLCHAIN=/home/user/bolt-aarch32/build-atfe-noassert/bin
export BOLT_RT_LIB=/home/user/bolt-aarch32/build-atfe/bolt-rt-baremetal-arm/libbolt_rt_baremetal.a
export ARM_INSTRUMENTATION_CONTRACT=privileged-single-core-no-fiq BOLT_FUNC=bolt_bench_stair_kernel BOLT_PROFILE_MODE=edges
cd "$ROOT"
for flavor in counter sample; do
  export VARIANTS_DIR="$ROOT/build-atfe/c3-$flavor-off"
  mkdir "$VARIANTS_DIR"
  cp "$ROOT/build-atfe/c3-$flavor/pgo_thinlto."{elf,bin} "$VARIANTS_DIR/"
  if [ "$flavor" = counter ]; then bash scripts/bolt-variant.sh instrument pgo_thinlto; fi
  export BOLT_FDATA="$ROOT/build-atfe/c3-$flavor/pgo_thinlto.fdata"
  bash scripts/bolt-variant.sh optimize pgo_thinlto
  for stem in pgo_thinlto_bolt $(if [ "$flavor" = counter ]; then echo pgo_thinlto.instr; fi); do
    ON="$ROOT/build-atfe/c3-$flavor/$stem"
    OFF="$VARIANTS_DIR/$stem"
    cmp "$ON.bin" "$OFF.bin"
    "$TOOLCHAIN/llvm-objcopy" --remove-section=.note.bolt_info "$ON.elf" "$VARIANTS_DIR/$stem.on.nonote"
    "$TOOLCHAIN/llvm-objcopy" --remove-section=.note.bolt_info "$OFF.elf" "$VARIANTS_DIR/$stem.off.nonote"
    cmp "$VARIANTS_DIR/$stem.on.nonote" "$VARIANTS_DIR/$stem.off.nonote"
    bash scripts/check-no-fpu.sh "$OFF.elf"
  done
  mkdir -p "$WIN/out/c3-fe/$flavor-off"
  cp "$VARIANTS_DIR"/* "$WIN/out/c3-fe/$flavor-off/"
done
echo 'PASS: ON/OFF instrumentation and both profile-mode optimized binaries match; ELFs match excluding command-line .note.bolt_info only; no-FPU scans pass'
