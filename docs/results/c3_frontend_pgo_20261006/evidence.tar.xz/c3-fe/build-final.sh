#!/usr/bin/env bash
set -euo pipefail
ROOT=/home/user/bolt-fe-20261006
WIN=/mnt/c/Users/User/CURSOR/CodexProjects/BOLT_AARCH32
export BASE=atfe CLANG_BINDIR=/home/user/bolt-aarch32/build-atfe/bin TOOLCHAIN=/home/user/bolt-aarch32/build-atfe/bin
export VARIANTS_DIR="$ROOT/build-atfe/c3-fe-thumb" LK_PROJECT=rpi4-bolt-test LK_MAKE_ARGS=STAIR_M=8 BOLT_BENCH_ISA=thumb JOBS=8
export PROFDATA="$VARIANTS_DIR/frontend.profdata"
cd "$ROOT"
cp "$WIN/out/c3-fe/compiler/frontend.profraw" "$VARIANTS_DIR/"
"$TOOLCHAIN/llvm-profdata" merge "$VARIANTS_DIR/frontend.profraw" -o "$PROFDATA"
python3 scripts/pgo_profile.py validate "$PROFDATA" --kind frontend --profdata "$TOOLCHAIN/llvm-profdata" > "$VARIANTS_DIR/frontend-profile.json"
bash scripts/build-variants.sh pgo pgo_thinlto
cp "$VARIANTS_DIR"/* "$WIN/out/c3-fe/compiler/"
python3 scripts/lk_coverage_report.py --elf "$VARIANTS_DIR/pgo_thinlto.elf" --toolchain "$TOOLCHAIN" --out "$ROOT/out/c3-fe-coverage" --json "$VARIANTS_DIR/pgo_thinlto.coverage.json" > "$VARIANTS_DIR/pgo_thinlto.coverage.log"
cp "$VARIANTS_DIR"/pgo_thinlto.coverage.* "$WIN/out/c3-fe/compiler/"
