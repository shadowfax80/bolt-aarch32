import csv,hashlib,json,statistics,sys
from pathlib import Path
root=Path(__file__).resolve().parents[2];out=root/'out/c3-fe';sys.path[:0]=[str(root/'scripts/pi4'),str(root/'scripts')]
from stats_util import mean_ci95
from profile_identity import sha256
sets=[]
for name,checksum in [('bolt-performance-v0','0x2f744325'),('bolt-performance-v1','0xce57eab7'),('bolt-performance-v2','0x5806b01f'),('compiler-performance','0x2f744325')]:
    rows=list(csv.DictReader((out/(name+'.csv')).open()));assert len(rows)==12
    names=['baseline','fe_pgo','fe_thinlto'] if name=='compiler-performance' else ['fe_thinlto','counter_bolt','sampled_bolt']
    assert set(r['variant'] for r in rows)==set(names)
    assert all(r['acc']==checksum and all(r[f] for f in ['cycles','inst','l1i_refill','l1d_refill','br_mispred','taken']) for r in rows)
    means={};cis={}
    for n in names:
        chosen=[r for r in rows if r['variant']==n];assert {(int(r['round']),int(r['run'])) for r in chosen}=={(i,j) for i in range(1,3) for j in range(1,3)}
        means[n],cis[n]=mean_ci95([int(r['cycles']) for r in chosen])
    sets.append(dict(name=name,records=12,checksum=checksum,mean_cycles=means,mean_ci95_half_width_cycles=cis,delta_percent_vs_first={n:100*(means[n]/means[names[0]]-1) for n in names[1:]},csv_sha256=sha256(out/(name+'.csv'))))
pc=json.loads((out/'rewritten-pc.json').read_text());assert pc['passed']
comparison=json.loads(next(out.glob('result-consistency-*/comparison.json')).read_text());assert comparison['result_consistency'] and len(comparison['workload_results'])==7
sample=json.loads((out/'sample/stair0.samples.manifest.json').read_text());assert sample['kept']==sample['taken'] and sample['verified_binding']
profile=json.loads((out/'compiler/frontend-profile.json').read_text());assert profile['ordinary']['level']=='Front-end' and profile['ordinary']['maximum']>0
identity=json.loads((out/'identity.json').read_text())
for name,digest in identity['compiler_artifact_sha256'].items():assert sha256(out/'compiler'/name)==digest
identity['frontend_collection']=json.loads((out/'frontend-training/collection.json').read_text())
assert identity['frontend_collection']['profile_sha256']==sha256(out/'compiler/frontend.profraw')
summary=dict(item='C3',backend_overlays='0001-0073',backend_changed=False,frontend_profile=profile['ordinary'],frontend_raw_bytes=(out/'compiler/frontend.profraw').stat().st_size,compiler_identity=identity,source_replay_identity=json.loads((out/'replay.json').read_text())['source_identity_sha256'],sample_capture=dict(kept=sample['kept'],taken=sample['taken'],period=sample['period'],repetitions=sample['repetitions'],manifest_sha256=sha256(out/'sample/stair0.samples.manifest.json')),counter_flow=json.loads((out/'counter-flow.json').read_text()),assertion_mode_parity='Identical instrumentation and both optimized load binaries; ELF excludes command-line .note.bolt_info only',output_consistency=dict(images=list(comparison['workload_results']),workloads=18,passed=True,scope='fresh baseline equality, no independent oracle or whole-image certification claim'),rewritten_pc=pc,measurements=sets,measurement_scope='48 complete records; two interleaved rounds x two runs per image; source configuration fixed within C3. Within-boot observations share caches/predictor state. Pi A72 synthetic kernel only; not a controlled comparison with C1/R35 CSPGO runs.',legacy_launcher_scope='Low-level explicit frontend variants in isolated checkout verified; pgo_cycle_wsl.sh --frontend shared synchronization/fixed paths were not rerun',known_limits=['module-scoped frontend/compiler ThinLTO','single selected BOLT kernel','sequential profiling without value profiling','counter single-core/no-FIQ contract','sampling cannot see IRQ-masked execution and infers edges','no new A55 or full-image oracle certificate'])
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for s in sets:print(s['name'],s['mean_cycles'],s['delta_percent_vs_first'])
