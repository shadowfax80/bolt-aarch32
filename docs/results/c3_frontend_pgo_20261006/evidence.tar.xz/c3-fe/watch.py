import json,re,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[2];out=root/'out/c3-fe'
sys.path[:0]=[str(root/'scripts')]
from profile_identity import elf_metadata,sha256
rows=[]
for label,folder,stem in [('instrumented','counter','pgo_thinlto.instr'),('counter-bolt','counter','pgo_thinlto_bolt'),('sampled-bolt','sample','pgo_thinlto_bolt')]:
    elf=out/folder/(stem+'.elf');image=out/folder/(stem+'.bin')
    _,symbols=elf_metadata(elf.read_bytes());sym=next(s for s in symbols if s['name']=='bolt_bench_stair_kernel' and s['kind']==2)
    lo=sym['address'];hi=lo+sym['size']
    argv=[sys.executable,str(root/'scripts/pi4/pi4_run.py'),str(image),'--port','COM5','--reboot','--wait','30','--max-wait','120','--wdog','180',f'bolt_sample watch {lo:x} {hi:x}','bolt_sample start 20000','bolt_bench stair 0 0','bolt_bench stair 0 0','bolt_sample stop']
    p=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=420)
    log=out/('watch-'+label+'.log');log.write_bytes(p.stdout);assert p.returncode==0,(label,p.returncode)
    text=p.stdout.decode('utf-8','replace');hits=re.findall(r'bolt_sample: watch 0 hits per core: (\d+) (\d+) (\d+) (\d+)',text)
    assert len(hits)==1 and sum(map(int,hits[0]))>0
    assert re.findall(r'bolt_bench: stair acc=(0x[0-9a-f]+)',text)==['0x2f744325']*2
    assert '$ wdog 0' in text
    rows.append(dict(label=label,elf_sha256=sha256(elf),image_sha256=sha256(image),range=[hex(lo),hex(hi)],hits_per_core=list(map(int,hits[0])),log_sha256=sha256(log),sampler_stopped=True,watch_ranges_cleared=True,watchdog_disabled=True))
(out/'rewritten-pc.json').write_text(json.dumps(dict(passed=True,rows=rows,scope='Pi A72 PC watch inside each mapped rewritten body; sampling changes visibility, not a timing or whole-image certification claim'),indent=2)+'\n')
print(json.dumps(rows,indent=2))
